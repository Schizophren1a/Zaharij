﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Viktorina
{
    public partial class Form2 : Form
    {
        string[] jautajumi = new string[] {
            "KAS IR PROGRAMēšANA?",
            "Kura ir vispopulārākā programēšanas valoda?",
            "Kas ir masīvs?",
            "Kas ir cikls?",
            "Kas ir optimizācija?",
            "Kāda ir pirmā programmēšanas valoda?",
            "Kāds atslēgas vārds tiek izmantots, lai deklarētu mainīgo C#?",
            "Ko dara git commit operators Git versiju kontroles sistēmā?",
            "Kā sauc augstākā līmeņa koda pārveidošanas procesu par zemākā līmeņa mašīnkoda?",
            "Kāda datu tipu izmanto, lai glabātu veselus skaitļus Java valodā?",
            "Kā sauc ciklu Python valodā, kas tiek izpildīts tik ilgi, kamēr nosacījums ir patiess?",
            "Kā saucas valoda, ko izmanto, lai veiktu datu bāzes SQL vaicājumus?",
            "Ko nozīmē HTML akronīms tīmekļa izstrādē?",
            "Kāda ir faila paplašinājuma Python valodas avotkodam?",
            "Kāds notikums notiek, kad tiek noklikšķināts uz elementa tīmekļa lapā?",
            "Kāda ir faila paplašinājuma Python valodas avotkodam?",
            "Kā saucas process, kas ļauj programmatūrai izpildīt vairākas darbības vienlaicīgi?",
            "Kāda ir Java un C++ valodas funkcija, kas izpilda konkrētu uzdevumu un neizmanto atgriezenisko vērtību?",
            "Kā sauc JavaScript funkciju, kas tiek izpildīta automātiski, kad notiek kāds notikums?",
            "Kā saucas datu struktūra, kas glabā elementus pēc \"pēdējā ienāk, pirmajā iznāk\" principa?"
        };
        string[] atbildes1 = new string[] {
            "Datorprogrammas izveides process",
            "Python",
            "Masīvs ir blakus esošo atmiņas apgabalu kopa, kas dzes datus.",
            "Cikls ir valodas konstrukcija, kas var noteikt programmas posmu vairākkārtējai atkārtošanai un šo atkārtojumu skaitu.",
            "Optimizācija ir sistēmas modifikācija.",
            "PHP",
            "var",
            "dzēš",
            "kompilācija",
            "int",
            "while",
            "SQL",
            "uzkārtošanas valoda",
            "funk",
            "click",
            ".py",
            "multithreading",
            "void",
            "events",
            "steg"
        };
        string[] atbildes2 = new string[] {
            "Video speles izveide",
            "C++",
            "Masīvs ir blakus esošo atmiņas apgabalu kopa, kas glabā visus tipa datus.",
            "Cikls ir programēšanas valoda.",
            "Optimizācija ir sistēmas modifikācija, lai uzlabotu tās efektivitāti.",
            "JavaScript",
            "exe",
            "fiksē",
            "kompilators",
            "GO",
            "else",
            "PHP",
            "iekārtošanas valoda",
            "function",
            "wheelup",
            ".css",
            "multitool",
            "int",
            "event arg",
            "steks"
        };
        string[] atbildes3 = new string[] {
            "Interneta programma",
            "JavaScript",
            "Masīvs ir blakus esošo atmiņas apgabalu kopa, kas glabā noteikta tipa datus.",
            "Cikls ir valodas konstrukcija, kas var noteikt programmas posmu vairākkārtējai atkārtošanai un šo atkārtojumu skaitu.",
            "Optimizācija ir sistēmas modifikācija, lai ta butu skaistak.",
            "Fortran",
            "zip",
            "izslēdz",
            "SQL",
            "string",
            "if",
            "MYSQL",
            "izkārtošanas valoda",
            "find",
            "rightclick",
            ".exe",
            "multitask",
            "double",
            "event handler",
            "stack"
        };
        string[] atbildes = new string[] {
            "Datorprogrammas izveides process",
            "JavaScript",
            "Masīvs ir blakus esošo atmiņas apgabalu kopa, kas glabā noteikta tipa datus.",
            "Cikls ir valodas konstrukcija, kas var noteikt programmas posmu vairākkārtējai atkārtošanai un šo atkārtojumu skaitu.",
            "Optimizācija ir sistēmas modifikācija, lai uzlabotu tās efektivitāti.",
            "Fortran",
            "var",
            "fiksē",
            "kompilācija",
            "int",
            "while",
            "SQL",
            "iekārtošanas valoda",
            "function",
            "click",
            ".py",
            "multithreading",
            "void",
            "event handler",
            "steks"
        };
        int piemeri = 0;
        public static int punkti = 0;

        List<int> izveletieJautajumi = new List<int>();

        public Form2()
        {
            InitializeComponent();
            IzvelētRandomJautajumus();
        }

        private void IzvelētRandomJautajumus()
        {
            Random rand = new Random();

            while (izveletieJautajumi.Count < 10)
            {
                int randomJautajums = rand.Next(0, jautajumi.Length);

                if (!izveletieJautajumi.Contains(randomJautajums))
                {
                    izveletieJautajumi.Add(randomJautajums);
                }
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            NomainitJautajumu();
        }

        private void butAtbilde1_Click(object sender, EventArgs e)
        {
            if (butAtbilde1.Text == atbildes[izveletieJautajumi[piemeri]]) punkti++;
            else if (punkti > 0) punkti--;

            piemeri++;

            if (piemeri < 10)
            {
                NomainitJautajumu();
            }
            else
            {
                this.Hide();
                Form3 rezultats = new Form3();
                rezultats.Show();
            }
        }

        private void butAtbilde2_Click(object sender, EventArgs e)
        {
            if (butAtbilde2.Text == atbildes[izveletieJautajumi[piemeri]]) punkti++;
            else if (punkti > 0) punkti--;

            piemeri++;

            if (piemeri < 10)
            {
                NomainitJautajumu();
            }
            else
            {
                this.Hide();
                Form3 rezultats = new Form3();
                rezultats.Show();
            }
        }

        private void butAtbilde3_Click(object sender, EventArgs e)
        {
            if (butAtbilde3.Text == atbildes[izveletieJautajumi[piemeri]]) punkti++;
            else if (punkti > 0) punkti--;

            piemeri++;

            if (piemeri < 10)
            {
                NomainitJautajumu();
            }
            else
            {
                this.Hide();
                Form3 rezultats = new Form3();
                rezultats.Show();
            }
        }

        private void NomainitJautajumu()
        {
            int indeks = izveletieJautajumi[piemeri];
            labJautajums.Text = jautajumi[indeks];
            butAtbilde1.Text = atbildes1[indeks];
            butAtbilde2.Text = atbildes2[indeks];
            butAtbilde3.Text = atbildes3[indeks];
            labPiemers.Text = (piemeri + 1) + ". no 10 jautājumiem";
        }
    }
}