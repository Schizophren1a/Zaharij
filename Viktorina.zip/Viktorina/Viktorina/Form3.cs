﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Viktorina
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            labRezultats.Text = Form2.punkti + " punkti";

            if (Form2.punkti == 10)
            {
                labRezultats.Text += "\nTu esi ģēnijs! Tu zini visu par visām programmēšanas valodām. Tev jāstrādā Google.";
            }
            else if (Form2.punkti >= 6 && Form2.punkti <= 9)
            {
                labRezultats.Text += "\nTu daudz ko zini par programmēšanu. Vēl mazliet un kļūsi labāks par visiem!";
            }
            else
            {
                labRezultats.Text += "\nTev vajadzētu uzlabot savas zināšanas, ja vēlies kļūt par labu programmētāju.";
            }
        }
    }
}
