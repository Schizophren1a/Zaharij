﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Viktorina
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void butSakt_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 jautajumi = new Form2();
            jautajumi.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
